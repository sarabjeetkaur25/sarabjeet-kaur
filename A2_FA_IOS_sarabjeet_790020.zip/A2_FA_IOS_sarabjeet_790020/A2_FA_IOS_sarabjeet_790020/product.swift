//
//  product.swift
//  A2_FA_IOS_sarabjeet_790020
//
//  Created by user186818 on 2/1/21.
//

import Foundation
struct Product{
    internal init(productid: Int, productName: String, prductDescription: String, productPrice: Int, productprovider: String) {
        self.productid = productid
        self.productName = productName
        self.prductDescription = prductDescription
        self.productPrice = productPrice
        self.productprovider = productprovider
    }
    
    var productid: Int
    var productName: String
    var prductDescription: String
    var productPrice: Int
    var productprovider: String
}
