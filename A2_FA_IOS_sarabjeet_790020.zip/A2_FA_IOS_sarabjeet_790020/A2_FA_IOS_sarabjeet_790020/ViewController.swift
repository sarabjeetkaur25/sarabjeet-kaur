//
//  ViewController.swift
//  A2_FA_IOS_sarabjeet_790020
//
//  Created by user186818 on 2/1/21.
//

import UIKit

class ViewController: UIViewController {
    var product:[Product]?

    @IBOutlet weak var textfields: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        loadData()
        product.setvalue("1",forKey: productid)
        
        // Do any additional setup after loading the view.
    }

    @IBAction func addbtnpreesed(_ sender: Any) {
        let productid = textfields.text ?? " "
        let productName = textfields.text ?? ""
        let productDescription = textfields.text ?? ""
        let productPrice = Int(textfields.text ?? "0") ?? 0
        let productProvider = textfields.text ?? ""
        let product = Product(productid: productid, productName: productName, productDescription: productDescription, productPrice: productPrice, productProvider: productProvider)
        
    }
    //func getDataFielPath() -> String {
      //  let documentpath = NSSearchpathForDirectoriesInDomains(.documentDirectory, .userdomaiMask, true)[0]
        //let filePath = documentPath.appending("/data.text")
        //return filePath
 //   }
    func loadData(){
        product = [Product]()
        let filePath = getDataFilePath()
        if FileManager.default.fileExists(atPath:filePath){
            do{
                let fileContent = try String(contentofFile:filePath)
                let contentArray = fileContent.components(separatedBy:"\n")
                for content in contentArray{
                    let productContent  =  content.components(separatedBy: ",")
                    if productContent.count == 5{
                        let product = product(id: productContent[0], name: productContent[1], discription: productContent[2], prise: productContent[3], provider: productcontent[4])
                        product?.apppend(product)
                    }
                }
            } catch{
                print(error)
            }
        }
    }
    override func prepare(for segue: UIStoryboardSegue,sender:Any?){
        if let productlisttableviewcontroller = segue.destination as?  product_listTableViewController{
            productlisttableviewcontroller.product = product
        }  }
    func saveData() {
        let filePath = getDataFilePath()
        var saveString = ""
        for product in  product!{
            saveString = "\(saveString)\(product.productid),\(product.productName), \(product.productPrice), \(product.productprovider)\n"
        }
        do{
            try saveString.Write(toFile: filePath,atomicallyL: true, encoding: .utf8)
        }catch{
            print(error)
        }
    }
}

